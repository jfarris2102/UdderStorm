Team: Udderstorm
Members: Niklas Carlson, Conor Mahoney, Justin Farris, Dawson Kelly.

This prototype introduces the core concept of our game which is building a colony on Mars. Different buildings will provide various recource generation based on their type. Currently only a handful of buildings are implemented. Note: Research tech trees and earth view(which will provide an interface for accessing research) are not yet implemented. Furthermore current base resource values are set to high values for testing purposes. In the full game they will start at 0 and the player will have to generate cash through earth based research. The player will then every so often launch buildings to Mars which will require effective time and resource management skills.

See Tutorial for controls.